<?php
/**
 * dbAdmin
 *
 * Copyright 2018-2026 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package dbadmin
 * @subpackage classfile
 */

namespace Sergant210\dbAdmin;

use modLexicon;
use modX;
use Sergant210\dbAdmin\Helper\Database;

/**
 * Class dbAdmin
 */
class dbAdmin
{
    /**
     * A reference to the modX instance
     * @var modX $modx
     */
    public $modx;

    /**
     * The namespace
     * @var string $namespace
     */
    public $namespace = 'dbadmin';

    /**
     * The package name
     * @var string $packageName
     */
    public $packageName = 'dbAdmin';

    /**
     * The version
     * @var string $version
     */
    public $version = '1.5.0';

    /**
     * The class options
     * @var array $options
     */
    public $options = [];

    /**
     * The database helper class
     * @var Database $database
     */
    public $database = null;

    /**
     * dbAdmin constructor
     *
     * @param modX $modx A reference to the modX instance.
     * @param array $options An array of options. Optional.
     */
    public function __construct(modX &$modx, $options = [])
    {
        $this->modx =& $modx;

        $corePath = $this->getOption('core_path', $options, $this->modx->getOption('core_path', null, MODX_CORE_PATH) . 'components/' . $this->namespace . '/');
        $assetsPath = $this->getOption('assets_path', $options, $this->modx->getOption('assets_path', null, MODX_ASSETS_PATH) . 'components/' . $this->namespace . '/');
        $assetsUrl = $this->getOption('assets_url', $options, $this->modx->getOption('assets_url', null, MODX_ASSETS_URL) . 'components/' . $this->namespace . '/');
        $modxversion = $this->modx->getVersionData();

        // Load some default paths for easier management
        $this->options = array_merge([
            'namespace' => $this->namespace,
            'version' => $this->version,
            'corePath' => $corePath,
            'modelPath' => $corePath . 'model/',
            'vendorPath' => $corePath . 'vendor/',
            'chunksPath' => $corePath . 'elements/chunks/',
            'pagesPath' => $corePath . 'elements/pages/',
            'snippetsPath' => $corePath . 'elements/snippets/',
            'pluginsPath' => $corePath . 'elements/plugins/',
            'controllersPath' => $corePath . 'controllers/',
            'processorsPath' => $corePath . 'processors/',
            'templatesPath' => $corePath . 'templates/',
            'assetsPath' => $assetsPath,
            'assetsUrl' => $assetsUrl,
            'jsUrl' => $assetsUrl . 'js/',
            'cssUrl' => $assetsUrl . 'css/',
            'imagesUrl' => $assetsUrl . 'images/',
            'connectorUrl' => $assetsUrl . 'connector.php'
        ], $options);

        $lexicon = $this->modx->getService('lexicon', modLexicon::class);
        $lexicon->load($this->namespace . ':default');

        $this->packageName = $this->modx->lexicon('dbadmin');

        $this->modx->addPackage($this->namespace, $this->getOption('modelPath'));

        // Add default options
        $this->options = array_merge($this->options, [
            'debug' => $this->getBooleanOption('debug', [], false),
            'modxversion' => $modxversion['version'],
            'permissions' => $this->getPermissions(),
        ]);

        $this->database = new Database($this->modx, $this);
    }

    /**
     * Get a local configuration option or a namespaced system setting by key.
     *
     * @param string $key The option key to search for.
     * @param array $options An array of options that override local options.
     * @param mixed $default The default value returned if the option is not found locally or as a
     * namespaced system setting; by default this value is null.
     * @return mixed The option value or the default value specified.
     */
    public function getOption($key, $options = [], $default = null)
    {
        $option = $default;
        if (!empty($key) && is_string($key)) {
            if ($options != null && array_key_exists($key, $options)) {
                $option = $options[$key];
            } elseif (array_key_exists($key, $this->options)) {
                $option = $this->options[$key];
            } elseif (array_key_exists("$this->namespace.$key", $this->modx->config)) {
                $option = $this->modx->getOption("$this->namespace.$key");
            }
        }
        return $option;
    }

    /**
     * Get Boolean Option
     *
     * @param string $key
     * @param array $options
     * @param mixed $default
     * @return bool
     */
    public function getBooleanOption($key, $options = [], $default = null)
    {
        $option = $this->getOption($key, $options, $default);
        return ($option === 'true' || $option === true || $option === '1' || $option === 1);
    }

    /** This method returns an error
     *
     * @param string $message Error message
     * @param mixed $data .
     * @return array
     */
    public function error($message = '', $data = '')
    {
        $response = [
            'success' => FALSE,
            'message' => $message,
            'data' => $data
        ];

        return $response;
    }

    /**
     * Get the dbAdmin permissions of the current user. They only hide the
     * actions in the manager, the processors check them again.
     * @return array
     */
    public function getPermissions(): array
    {
        $access = [];
        $perms = [
            'sql_query_execute',
            'table_export',
            'table_remove',
            'table_save',
            'table_truncate',
            'table_view',
        ];
        // The service is created in the setup too, where no context is initialized
        $hasContext = is_object($this->modx->context);
        foreach ($perms as $p) {
            $access[$p] = $hasContext && $this->modx->hasPermission($p);
        }
        return $access;
    }
}
