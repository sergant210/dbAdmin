-- Created on: 3 Mar 2023, 11:37

--
-- Table structure `modx_access_context`
--

DROP TABLE IF EXISTS `modx_access_context`;
CREATE TABLE `modx_access_context` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) unsigned NOT NULL DEFAULT '0',
  `authority` int(10) unsigned NOT NULL DEFAULT '9999',
  `policy` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `target` (`target`),
  KEY `principal_class` (`principal_class`),
  KEY `principal` (`principal`),
  KEY `authority` (`authority`),
  KEY `policy` (`policy`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Data dump `modx_access_context`
--

INSERT INTO `modx_access_context` (`id`, `target`, `principal_class`, `principal`, `authority`, `policy`) VALUES
(1, 'web', 'modUserGroup', 0, 9999, 3),
(2, 'mgr', 'modUserGroup', 1, 0, 2),
(3, 'web', 'modUserGroup', 1, 0, 2),
(4, 'test', 'modUserGroup', 1, 9999, 11),
(5, 'test', 'modUserGroup', 0, 9999, 3),
(6, 'de', 'modUserGroup', 1, 0, 2),
(7, 'fr', 'modUserGroup', 1, 0, 2),
(8, 'de', 'modUserGroup', 0, 9999, 3),
(9, 'fr', 'modUserGroup', 0, 9999, 3),
(10, 'web', 'modUserGroup', 2, 9999, 13),
(11, 'mgr', 'modUserGroup', 1, 9999, 14),
(12, 'web', 'modUserGroup', 3, 9999, 11),
(13, 'web', 'modUserGroup', 4, 9999, 11),
(14, 'mgr', 'modUserGroup', 1, 9999, 16),
(15, 'mgr', 'modUserGroup', 1, 9999, 17),
(19, 'mgr', 'modUserGroup', 1, 9999, 18),
(18, 'web', 'modUserGroup', 10029, 9999, 11),
(20, 'mgr', 'modUserGroup', 10029, 9999, 20);

-- --------------------------------------------------------

