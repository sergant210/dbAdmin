dbAdmin.panel.Home = function (config) {
    config = config || {};
    Ext.apply(config, {
        cls: 'container home-panel' + ' modx' + dbAdmin.config.modxversion,
        defaults: {
            collapsible: false,
            autoHeight: true
        },
        items: [{
            html: '<h2>' + _('dbadmin') + '</h2>',
            border: false,
            cls: 'modx-page-header'
        }, {
            defaults: {
                autoHeight: true
            },
            border: true,
            items: [{
                xtype: 'dbadmin-panel-overview'
            }]
        }]
    });
    dbAdmin.panel.Home.superclass.constructor.call(this, config);
};
Ext.extend(dbAdmin.panel.Home, MODx.Panel);
Ext.reg('dbadmin-panel-home', dbAdmin.panel.Home);

dbAdmin.panel.HomeTab = function (config) {
    config = config || {};
    Ext.applyIf(config, {
        id: 'dbadmin-panel-' + config.tabtype,
        title: config.title,
        items: [{
            html: '<p>' + config.description + '</p>',
            border: false,
            cls: 'panel-desc'
        }, {
            layout: 'form',
            cls: 'x-form-label-left main-wrapper',
            defaults: {
                autoHeight: true
            },
            border: true,
            items: [{
                id: 'dbadmin-panel-' + config.tabtype + '-grid',
                xtype: 'dbadmin-grid-' + config.tabtype,
                preventRender: true
            }]
        }]
    });
    dbAdmin.panel.HomeTab.superclass.constructor.call(this, config);
};
Ext.extend(dbAdmin.panel.HomeTab, MODx.Panel);
Ext.reg('dbadmin-panel-hometab', dbAdmin.panel.HomeTab);

dbAdmin.panel.Overview = function (config) {
    config = config || {};
    this.ident = 'dbadmin-overview-' + Ext.id();
    this.panelOverviewTabs = [{
        xtype: 'dbadmin-panel-hometab',
        title: _('dbadmin.tables'),
        description: _('dbadmin.tables_desc'),
        tabtype: 'tables'
    }, {
        xtype: 'dbadmin-panel-sql'
    }];
    Ext.applyIf(config, {
        items: [{
            id: 'dbadmin-tabpanel',
            xtype: 'modx-tabs',
            border: true,
            stateful: true,
            stateId: 'dbadmin-panel-overview',
            stateEvents: ['tabchange'],
            getState: function () {
                return {
                    activeTab: this.items.indexOf(this.getActiveTab())
                };
            },
            autoScroll: true,
            deferredRender: true,
            forceLayout: false,
            defaults: {
                layout: 'form',
                autoHeight: true,
                hideMode: 'offsets'
            },
            items: this.panelOverviewTabs,
            listeners: {
                tabchange: function (o, t) {
                    if (t.xtype === 'dbadmin-panel-hometab') {
                        if (Ext.getCmp('dbadmin-panel-' + t.tabtype + '-grid')) {
                            Ext.getCmp('dbadmin-panel-' + t.tabtype + '-grid').getStore().reload();
                        }
                    }
                }
            }
        }]
    });
    dbAdmin.panel.Overview.superclass.constructor.call(this, config);
};
Ext.extend(dbAdmin.panel.Overview, MODx.Panel);
Ext.reg('dbadmin-panel-overview', dbAdmin.panel.Overview);
